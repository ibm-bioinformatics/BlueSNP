# ##################################################
#
# Copyright IBM Corp. 2011, 2012
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# 
# ##################################################

ONEMIN = 60000  # ms
RHIPE_MAP_BUFFSIZE    = 100  # number of records per batch **250MB Rhipe limit**
RHIPE_REDUCE_BUFFSIZE = 100  # much safer than the default of 10,000 records

.onAttach <- function(libname, pkgname) {
  version <- read.dcf(file=system.file("DESCRIPTION", package=pkgname), fields="Version")
  packageStartupMessage(paste("\n", pkgname, version, "\n", "
    # ##################################################
    #
    # Copyright IBM Corp. 2011, 2012
    # 
    # Licensed under the Apache License, Version 2.0 (the \"License\");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    # 
    #     http://www.apache.org/licenses/LICENSE-2.0
    # 
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an \"AS IS\" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    # 
    # ##################################################
  ")
  )
}
gwas.adaptive.perm <- function(
  genotype.hdfs.path,             # genotype dir
  phenotype.hdfs.path,            # phenotype Rdata file (must fit in mapper memory)
  output.hdfs.path,               # results dir
  phenotype.cols=1,               # only one phenotype allowed
  method="qt.linear.regression",  # a built-in or custom test (see user.code.hdfs.path option)
  statistic.name="t.statistic",   # result[[statistic.name]]
  hit.report.cutoff=10,            # only report SNPs with this many or fewer random hits
  user.code=NULL,                 # hdfs path to user-defined assoc tests
  minutes.until.timeout=10,       # override hadoop default
  n.permutations=1E6,             # total number of permutations
  # expert settings for adding more permutations to an output folder
  k=0,
  total.tries=0,
  n.not.finished=1,  # a small number greater than zero
  previous.n.not.finished=Inf
) {

  rhinit.singleton()

  # validations
  if (length(phenotype.cols)!=1)
    stop("we only allow for one phenotype in phenotype.cols when performing permutations")

  # initialize
  output.hdfs.root = output.hdfs.path
  is.not.finished = T
  
  if (k==0) {  # this is a new job
    k = k + 1
    total.tries = 1E5
    output.hdfs.path = paste(output.hdfs.root, "/run/", k, sep="")
    j = gwas.perm.run(
      genotype.hdfs.path,
      phenotype.hdfs.path,
      output.hdfs.path,
      method=method,
      statistic.name=statistic.name,
      phenotype.cols=phenotype.cols,
      is.maxT=F,
      is.premature.stop=T,
      is.report.all.stats=F,
      is.reduce=T,
      n.permutations=total.tries,
      user.code=user.code,
      minutes.until.timeout=minutes.until.timeout
    )
    n.not.finished = j$counters$PROGRESS["_IS_NOT_FINISHED_"]
    is.not.finished = n.not.finished > 0
  }
  
  # ##################################################
  # main loop

  # helpers to pick reasonable numbers of copies and permutations per copy
  n.copies = pick.copies(total.tries)
  n.permutations.block = pick.permutations(total.tries)

  while (is.not.finished & total.tries < n.permutations) {

    if (n.not.finished < previous.n.not.finished) {  # the number of not-finished-snps decreased
      # re-pick the number of copies and permutations
      n.copies = pick.copies(total.tries)
      n.permutations.block = pick.permutations(total.tries)
      # broadcast
      genotype.hdfs.path = paste(output.hdfs.root, "/run/", k, sep="")
      output.hdfs.path   = paste(output.hdfs.root, "/broadcast/", k, sep="")
      j = gwas.perm.broadcast(genotype.hdfs.path, output.hdfs.path, n.copies=n.copies)
      n.not.finished = j$counters$PROGRESS["_IS_NOT_FINISHED_"]
      
    } else {
      # move previous broadcast to new location (copy and delete)
      old.hdfs.path = paste(output.hdfs.root, "/broadcast/", k-1, sep="")
      new.hdfs.path = paste(output.hdfs.root, "/broadcast/", k, sep="")
      rhcp(old.hdfs.path, new.hdfs.path)
      rhdel(old.hdfs.path)
    }

    # pick a reasonable number of reducers for gwas.perm.run() below
    mapred.reduce.tasks = min(n.not.finished, reduce.task.capacity())

    # run permutations
    genotype.hdfs.path = paste(output.hdfs.root, "/broadcast/", k, sep="")
    output.hdfs.path   = paste(output.hdfs.root, "/run/", k+1, sep="")
    j = gwas.perm.run(
      genotype.hdfs.path,
      phenotype.hdfs.path,
      output.hdfs.path,
      method=method,
      statistic.name=statistic.name,
      phenotype.cols=phenotype.cols,
      is.maxT=F,
      is.premature.stop=T,
      is.report.all.stats=F,
      is.reduce=T,
      n.permutations=n.permutations.block,
      mapred.reduce.tasks=mapred.reduce.tasks,
      user.code=NULL,
      minutes.until.timeout=10,
      job.tag=k+1
    )
    previous.n.not.finished = n.not.finished  # remember previous number of candidate SNPs
    n.not.finished = j$counters$PROGRESS["_IS_NOT_FINISHED_"]
    is.not.finished = n.not.finished > 0

    total.tries = total.tries + n.copies * n.permutations.block
    k = k + 1
  }

  # collect
  input.hdfs.path  = paste(output.hdfs.root, "/run", sep="")
  output.hdfs.path = paste(output.hdfs.root, "/collect", sep="")
  gwas.perm.collect(input.hdfs.path, output.hdfs.path)
  
  # report
  input.hdfs.path = paste(output.hdfs.root, "/collect", sep="")
  output.hdfs.path = paste(output.hdfs.root, "/report", sep="")
  gwas.perm.report(input.hdfs.path, output.hdfs.path, hit.report.cutoff=hit.report.cutoff)

}

gwas.maxT.perm <- function(
  genotype.hdfs.path,             # genotype dir
  phenotype.hdfs.path,            # phenotype Rdata file (must fit in mapper memory)
  output.hdfs.path,               # results dir
  phenotype.cols=1,               # only one phenotype allowed
  method="qt.linear.regression",  # a built-in or custom test (see user.code.hdfs.path option)
  statistic.name="t.statistic",   # result[[statistic.name]]
  n.permutations=1000,            # total number of permutations
  hit.report.cutoff=5,            # only report SNPs with this many or fewer random hits
  user.code=NULL,                 # hdfs path to user-defined assoc tests
  minutes.until.timeout=10        # override hadoop default
) {

  # validations
  if (length(phenotype.cols)!=1)
    stop("we only allow for one phenotype in phenotype.cols when performing permutations")

  output.hdfs.root = output.hdfs.path

  # ##################################################
  # run permutations

  output.hdfs.path = paste(output.hdfs.root, "/run", sep="")
  gwas.perm.run(
    genotype.hdfs.path,
    phenotype.hdfs.path,
    output.hdfs.path,
    method,
    statistic.name,
    phenotype.cols=phenotype.cols,
    is.reduce=T,
    n.permutations=n.permutations,
    user.code=user.code,
    minutes.until.timeout=minutes.until.timeout
  )

  # ##################################################
  # find max test statistic in each round

  input.hdfs.path  = paste(output.hdfs.root, "/run", sep="")
  output.hdfs.path = paste(output.hdfs.root, "/findmax", sep="")
  gwas.maxT.perm.findmax(
    input.hdfs.path,
    output.hdfs.path,
    minutes.until.timeout=minutes.until.timeout
  )

  # ##################################################
  # p.value.adjusted

  input.hdfs.path  = paste(output.hdfs.root, "/run", sep="")
  output.hdfs.path = paste(output.hdfs.root, "/adjust", sep="")
  maxT.hdfs.path   = paste(output.hdfs.root, "/findmax", sep="")
  gwas.maxT.perm.adjust(
    input.hdfs.path,
    output.hdfs.path,
    maxT.hdfs.path,
    minutes.until.timeout=minutes.until.timeout
  )
  
  # ##################################################
  # report

  input.hdfs.path  = paste(output.hdfs.root, "/adjust", sep="")
  output.hdfs.path = paste(output.hdfs.root, "/report", sep="")
  gwas.perm.report(
    input.hdfs.path,
    output.hdfs.path,
    hit.report.cutoff=hit.report.cutoff,
    minutes.until.timeout=minutes.until.timeout
  )

}

# read the results of gwas() into the R worksapce
gwas.results <- function(
  output.hdfs.path,    # hdfs path to results dir (no trailing slash!)
  nrows = -1,          # maximum number of text rows to read from the HDFS part-xxxx files
  type = NULL, # "p.value" or "beta" or "se", etc.
  is.cleanup = T
) {
  
  rhinit.singleton()
  
  if (!file.exists("./tmp")) { 
    dir.create("./tmp") 
  } else {
    system("rm -r ./tmp")
    dir.create("./tmp") 
  }
  
  hdfs.path = paste(output.hdfs.path, "report/part*", sep="/")
  rhget(hdfs.path, "./tmp")
  if (is.null(type)) {
    system("cat ./tmp/part* > ./tmp/out.txt")
  } else {
    command = paste("cat ./tmp/part* | grep '", type, "' > ./tmp/out.txt", sep="")
    system(command)
  }
  
  d = data.frame(t(rep(NA, 4)))
  tryCatch({
    d = read.table("./tmp/out.txt", nrows=nrows, fill=T)  # jagged row lengths OK
  }, error=function(e) {
    # fails if out.txt is empty
    # e$message
  })
  
  # don't try to guess the phenotype names, but change the other names
  newnames = names(d)
  newnames[1:4] = c("type", "rsid", "chr", "bp")
  names(d) = newnames
  
  if (is.cleanup) {
    system("rm -r ./tmp")
  }
  
  d
}

# test
#d = gwas.results("t/results")
#p = gwas.results("t/results", type="p.value")

# read the results of gwas() into the R worksapce
gwas.results.perm <- function(
  output.hdfs.path,    # hdfs path to results dir (no trailing slash!)
  nrows = -1,          # maximum number of text rows to read from the HDFS part-xxxx files
  type = NULL, # "p.value" or "beta" or "se", etc.
  is.cleanup = F
) {
  
  rhinit.singleton()
  
  if (!file.exists("./tmp")) { 
    dir.create("./tmp") 
  } else {
    system("rm -r ./tmp")
    dir.create("./tmp") 
  }
  
  hdfs.path = paste(output.hdfs.path, "report/part*", sep="/")
  rhget(hdfs.path, "./tmp")
  if (is.null(type)) {
    system("cat ./tmp/part* > ./tmp/out.txt")
  } else {
    command = paste("cat ./tmp/part* | grep '", type, "' > ./tmp/out.txt", sep="")
    system(command)
  }
  
  d = data.frame(t(rep(NA, 10)))
  tryCatch({
    d = read.table("./tmp/out.txt", nrows=nrows)
  }, error=function(e) {
    # fails if out.txt is empty
    # e$message
  })

  names(d) = c("phenotype.name", "rsid", "chromosome", "position", 
    "p.value", "p.value.adjusted", "statistic.real", "hits", "tries", "is.finished")

  if (is.cleanup) {
    system("rm -r ./tmp")
  }
  
  d
}

# reshape the output of gwas.results() for one phenotype
gwas.results.reshape <- function(
  X # data.frame from gwas.results()
) {

  types = unique(X$type)
  row.ids = unique(X[,c("rsid", "chr", "bp")])
  rownames(row.ids) = NULL

  # build new table one col at a time
  Y = NULL
  for (i in seq_along(types)) {
    y = subset(X, type==types[i])[,5]  # col 5 is the first phenotype
    Y = cbind(Y, y)
  }
  colnames(Y) = types

  d = cbind(row.ids, Y)

  d
}

permutation.loop <- function(
  thecount,
  method, 
  statistic.name, 
  y, 
  x, 
  statistic.real, 
  n.permutations, 
  keepalive=NULL,         # keepalive gets the snp index number
  random.seed,            # value is crucial for maxT and adaptive to work properly
  is.premature.stop=F,    # default for maxT is to NOT do a premature stop
  is.report.all.stats=T   # default for maxT is to return all test stats
) {

  all.statistic.rand = NULL  # keep all of them (for maxT adjustment)

  # ##################################################
  # WARNING: the value of random.seed is crucial for maxT and adaptive permutation
  # to work properly
  
  if (!is.null(random.seed))  # only maxT is not NULL
    set.seed(random.seed)  # every mapper generates the same sample(y)
  else  # adaptive 
    set.seed(sample(999999999, 1))  # every mapper needs a different seed
  
  # ##################################################

  for (i in 1:n.permutations) {
    
    statistic.rand = eval(call(method, sample(y), x))[[statistic.name]]
    
    # increment the count
    if (abs(statistic.rand) >= abs(statistic.real))
      thecount = increment.hit(thecount)
    else
      thecount = increment.miss(thecount)

    if (is.report.all.stats)  # maxT reports all the random test statistics
      all.statistic.rand[i] = statistic.rand  # remember

    if (!is.null(keepalive))
      rhstatus(paste("SNP", keepalive, "Permutation", i))  # keepalive

    if (is.premature.stop) {  # adaptive stops permutations early if the hit limit is reached
      if (!(i %% 10)) {  # do every 10 iterations
        if (is.finished(thecount)) {
          break
        }
      }
    }

  }

  if (is.report.all.stats)  # maxT reports all the random test statistics
    list(thecount=thecount, statistic.random=all.statistic.rand)
  else
    list(thecount=thecount)
}

test.installation <- function() {

  rhinit.singleton()
  
  # simulated data files
  tped = system.file("simulated_cc.tped", package="BlueSNP")
  tfam = system.file("simulated_cc.tfam", package="BlueSNP")
  
  cat("Copying simulated_cc.tped to HDFS bluesnp_test/simulated_cc.tped\n")
  rhput(tped, "bluesnp_test/simulated_cc.tped", map.task.capacity())
  
  cat("Copying simulated_cc.tfam to HDFS bluesnp_test/simulated_cc.tfam\n")
  rhput(tfam, "bluesnp_test/simulated_cc.tfam")
  
  cat("Parsing tped file into SNP records\n")
  read.plink.tped("bluesnp_test/simulated_cc.tped", "bluesnp_test/snps")
  
  cat("Parsing tfam file into pheno.RData\n")
  read.plink.tfam("bluesnp_test/simulated_cc.tfam", "bluesnp_test/pheno.RData")
  
  cat("Run allelic test\n")
  gwas("bluesnp_test/snps", "bluesnp_test/pheno.RData", "bluesnp_test/results", 
    method="cc.allelic")
    
  cat("Fetching results\n")
  results = gwas.results("bluesnp_test/results")

  cat("Reshaping results\n")
  pretty = gwas.results.reshape(results)
  
  pretty
  
}

gwas <- function(
  genotype.hdfs.path,             # hdfs path to genotype dir
  phenotype.hdfs.path,            # hdfs path to phenotype Rdata file (must fit in memory)
  output.hdfs.path,               # hdfs path to results dir
  method="qt.linear.regression",  # a built-in or custom test
  phenotype.cols=NULL,            # subset of phenotype matrix col name/number
  pvalue.report.cutoff=1E-5,      # only report p-values less than this
  split.factor=1,                 # integer > 1 decreases the number of splits
  is.sparse.output=F,             # don't create a txt report
  user.code=NULL,                 # hdfs path to user-defined assoc tests
  minutes.until.timeout=10        # override hadoop default
) {

  mapred.min.split.size=128*1024*1024*split.factor

  rhinit.singleton()

  # at mapper startup, these files are copied from the hdfs to the mapper local fs at ./tmp/
  shared = append.user.code.to.shared(phenotype.hdfs.path, user.code)

  setup = expression({
    suppressPackageStartupMessages(library(BlueSNP))
  
    load(PHENOTYPE_FILE)             # variable substitution
    phenotype.cols = PHENOTYPE.COLS  # variable substitution
    
    # restrict Y to just the columns we are interested in
    # WARNING: output column number no longer corresponds to input column number
    Y = column.select(Y, phenotype.cols)
    phenotype.cols = 1:ncol(Y)  # redefine. overwrites NULL
    
    # phenotype.names default to colnames(), fallback to col numbers 
    # WARNING: phenotype.names[j] is the jth entry of the selected cols
    phenotype.names = colnames(Y)
    if (is.null(phenotype.names))
      phenotype.names = phenotype.cols
  })
  
  # expressionBuilder() performs variable substitution on ALL_CAPS
  setup = expressionBuilder(setup, 
    PHENOTYPE_FILE=deparse(stripPath(phenotype.hdfs.path)),
    PHENOTYPE.COLS=deparse(phenotype.cols)
  )
  setup = append.user.code.to.setup(setup, user.code)
  
  # ##################################################
  # MAP: Test SNP i for association with phenotype j
  # ##################################################

  map = expression({
    method = METHOD                               # variable substitution
    pvalue.report.cutoff = PVALUE.REPORT.CUTOFF   # variable substitution
    
    # trick to get the names of the assoc test output
    output.variable.names = eval(call(method))

    rhcounter("PROGRESS", "_TASK_", 1)

    for (i in seq_along(map.values)) {  # each snp record
      rhcounter("PROGRESS", "_IN_", 1)
      key = map.keys[[i]]
      value = map.values[[i]]

      chromosome = value$chromosome
      rsid       = value$rsid
      distance   = value$distance
      position   = value$position
      x          = value$snp.vector

      for (j in phenotype.cols) {  # each phenotype

        rhstatus(paste("SNP", i, "Phenotype", j))  # keepalive

        y = Y[,j]

        # statistical hypothesis test
        result = eval(call(method, y, x))

        if (result$p.value <= pvalue.report.cutoff) {  # only report if significant

          for (k in seq_along(output.variable.names)) {  # one report for each output variable
            statistic.name = output.variable.names[k]
            
            # collect all results for this rsid/stat compound key
            new.key = c(rsid, statistic.name)  # key like c("rs123", "p.value")

            new.value = list(
              chromosome=chromosome,
              rsid=rsid,
              distance = value$distance,
              position=position,
              statistic.name=statistic.name,
              statistic.number=k,
              statistic.value=result[[statistic.name]],
              phenotype.name=phenotype.names[j],
              phenotype.number=j,
              total.phenotype.count=length(phenotype.cols)  # tell reduce() output vector length
            )

            rhcollect(new.key, new.value)
            rhcounter("PROGRESS", "_OUT_", 1)
          }
        }
      }
    }
  })

  map = expressionBuilder(map, 
    METHOD=deparse(method),
    PVALUE.REPORT.CUTOFF=deparse(pvalue.report.cutoff)
  )

  # ##################################################
  # REDUCE: Reduce on key like c("rsid123", "p.value")
  # to collect all phenotypes for a compound key
  # ##################################################

  reduce = expression(
    pre={
      rhcounter("PROGRESS", "_TASK_", 1)
      key = reduce.key
      collected.results = NULL  # collect one line of results
    },
    reduce={
      for (i in seq_along(reduce.values)) {
        rhcounter("PROGRESS", "_IN_", 1)
        value = reduce.values[[i]]

        # these values are the same for every record in this reduce task
        chromosome            = value$chromosome
        rsid                  = value$rsid
        position              = value$position
        statistic.name        = value$statistic.name
        total.phenotype.count = value$total.phenotype.count

        # start to build the output, add collected.results in post={}
        new.value = list(
          statistic.name=statistic.name,
          rsid=rsid,
          chromosome=chromosome,
          position=position
        )

        # these values are specific to this record
        phenotype.number = value$phenotype.number
        phenotype.name   = value$phenotype.name
        statistic.value  = value$statistic.value

        # keepalive
        rhstatus(paste("Stat", statistic.name, "SNP", rsid, "Pheno", phenotype.number))

        # build the row: put statistic.value in the correct position
        collected.results[phenotype.number] = statistic.value
      }
    },
    post={
      # ensure collected results is the correct length
      tmp = as.numeric(rep(NA, total.phenotype.count))
      idx = which(!is.na(collected.results))
      tmp[idx] = collected.results[idx]
      collected.results = tmp
      
      #collected.results[is.na(collected.results)] = ""  # replace NA with "" (cosmetic)

      #new.value = c(new.value, collected.results=collected.results)
      new.value$collected.results = collected.results

      # emit one table row (could belong to any table)
      rhcollect(key, new.value)
      rhcounter("PROGRESS", "_OUT_", 1)
    }
  )
  
  # ##################################################

  inout = c("sequence", "sequence")
  ifolder = genotype.hdfs.path

  ofolder = NULL
  mapred.reduce.tasks=reduce.task.capacity()
  if (is.sparse.output) {
    ofolder = paste(output.hdfs.path, "/sparse", sep="")
    mapred.reduce.tasks = 0
  } else {
    ofolder = paste(output.hdfs.path, "/run", sep="")
  }

  jobname = "gwas.compute"
  z = rhmr(
    jobname=jobname,
    setup=setup,
    map=map,
    reduce=reduce,
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    shared=shared,
    orderby="character",
    partitioner=list(lims=c(1,2), type="string"),  # key like c("rs123", "p.value")
    mapred=list(
      mapred.map.tasks=map.task.capacity(),
      mapred.reduce.tasks=mapred.reduce.tasks,
      mapred.task.timeout=ONEMIN*minutes.until.timeout,
      rhipe_map_buffsize=RHIPE_MAP_BUFFSIZE,
      rhipe_reduce_buffsize=RHIPE_REDUCE_BUFFSIZE,
      mapred.min.split.size=mapred.min.split.size
    )
  )
  
  rhex(z, async=F)
  
  # At this point, each output row is assembled, but the rows are not yet
  # grouped by rsid. Do this by partitioning on rsid in another MR.

  if (!is.sparse.output) {

    # ##################################################
    # sort / report
    # ##################################################
    
    map = identity.map
    reduce = identity.reduce
    
    inout = c("sequence", "text")
    ifolder = paste(output.hdfs.path, "/run", sep="")
    ofolder = paste(output.hdfs.path, "/report", sep="")
    
    jobname = "gwas.report"
    z = rhmr(
      jobname=jobname,
      map=map,
      reduce=reduce,
      inout=inout,
      ifolder=ifolder,
      ofolder=ofolder,
      orderby="character",
      partitioner=list(lims=1, type="string"),  # partition on rsid
      mapred=list(
        mapred.map.tasks=map.task.capacity(),
        mapred.reduce.tasks=reduce.task.capacity(),
        mapred.task.timeout=ONEMIN*minutes.until.timeout,
        rhipe_map_buffsize=RHIPE_MAP_BUFFSIZE,
        rhipe_reduce_buffsize=RHIPE_REDUCE_BUFFSIZE,
        mapred.textoutputformat.usekey=F,
        mapred.field.separator="\t",
        mapred.textoutputformat.separator="\t"
      )
    )
    
    rhex(z, async=F)
  
  }

  #reduce.cleanup = expression({
  #  # write the col headers of the output format to the local fs and copy to hdfs
  #  header = paste(c("type", "rsid", "chromosome", "position", phenotype.names), collapse="\t")
  #  write.table(header,
  #    file="./tmp/header.txt",
  #    quote=F,
  #    row.names=F,
  #    col.names=F
  #  )
  #})
  

  # NOTE: reduce could be done with tall.to.wide() helper function
}

gwas.maxT.perm.adjust <- function(
  input.hdfs.path,
  output.hdfs.path,
  maxT.hdfs.path,
  minutes.until.timeout=10
) {

  # ################################################################################
  # p.value.adjusted
  # ################################################################################

  rhinit.singleton()

  maxT.hdfs.path = paste(maxT.hdfs.path, "/part-r-00000", sep="")
  
  shared = c(maxT.hdfs.path)

  setup = expression({
    suppressPackageStartupMessages(library(BlueSNP))
    myfile = MAXT_FILE
    maxT = as.numeric(read.table(myfile, header=F, row.names=1)[,1])
  })
  
  setup = expressionBuilder(setup, 
    MAXT_FILE=deparse(stripPath(maxT.hdfs.path))
  )
  
  map = expression({
    rhcounter("PROGRESS", "_TASK_", 1)
    
    for (i in seq_along(map.values)) {  # each snp record
      rhcounter("PROGRESS", "_IN_", 1)
      key = map.keys[[i]]
      value = map.values[[i]]
      
      statistic.real = value$statistic.real
      
      p.value.adjusted = sum(abs(maxT) >= abs(statistic.real)) / length(maxT)
  
      # update snp record
      value$p.value.adjusted = p.value.adjusted
      
      # emit snp record
      rhcollect(key, value)
      rhcounter("PROGRESS", "_OUT_", 1)
    }
  })
  
  inout = c("sequence", "sequence")
  ifolder = input.hdfs.path
  ofolder = output.hdfs.path
  
  jobname = "gwas.maxT.perm.adjust"
  z = rhmr(
    jobname=jobname,
    setup=setup, 
    map=map,
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    shared=shared,
    mapred = list(
      mapred.reduce.tasks=0,
      mapred.task.timeout=ONEMIN*minutes.until.timeout,
      rhipe_map_buffsize=RHIPE_MAP_BUFFSIZE,
      rhipe_reduce_buffsize=RHIPE_REDUCE_BUFFSIZE
    )
  )
  
  rhex(z, async=F)
  
}

gwas.maxT.perm.findmax <- function(
  input.hdfs.path,
  output.hdfs.path,
  minutes.until.timeout=10
) {

  # ################################################################################
  # step 1: find the max test statistic using many reducers --> sequence output
  # step 2: concat previous ouput into one ouput file --> text output
  # ################################################################################

  rhinit.singleton()

  setup = expression({
    suppressPackageStartupMessages(library(BlueSNP))
  })

  map = expression({
    rhcounter("PROGRESS", "_TASK_", 1)

    for (i in seq_along(map.values)) {  # each snp record
      rhcounter("PROGRESS", "_IN_", 1)
      key = map.keys[[i]]
      value = map.values[[i]]

      statistic.random = value$statistic.random
      for (j in seq_along(statistic.random)) {
        statistic = statistic.random[j]

        # emit
        rhcollect(j, statistic)  # find max(statistic) in the reducer
        rhcounter("PROGRESS", "_OUT_", 1)
      }
    }
  })

  reduce = expression(
    pre={
      rhcounter("PROGRESS", "_TASK_", 1)
      key = reduce.key
      value = NULL
      largest = 0
    },
    reduce={
      for (i in seq_along(reduce.values)) {
        rhcounter("PROGRESS", "_IN_", 1)
        value = reduce.values[[i]]

        if (abs(value) > largest)
          largest = abs(value)
      }
    },
    post={
      rhcollect(key, largest)  # emit one record per iteration
      rhcounter("PROGRESS", "_OUT_", 1)
    }
  )

  inout = c("sequence", "sequence")
  ifolder = input.hdfs.path
  ofolder = paste(output.hdfs.path, "_temp", sep="")
  
  jobname = "gwas.maxT.perm.findmax.step1"
  z = rhmr(
    jobname=jobname,
    setup=setup, 
    map=map,
    reduce=reduce, 
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    orderby="integer",
    partitioner=list(lims=1, type="integer"),
    mapred = list(
      mapred.reduce.tasks=reduce.task.capacity(),
      mapred.task.timeout=ONEMIN*minutes.until.timeout,
      rhipe_map_buffsize=RHIPE_MAP_BUFFSIZE,
      rhipe_reduce_buffsize=RHIPE_REDUCE_BUFFSIZE
    )
  )

  rhex(z, async=F)

  # ##################################################
  # step 2: concat previous ouput into one ouput file --> text output
  # ##################################################    
  
  map = identity.map
  reduce = identity.reduce

  inout = c("sequence", "text")
  ifolder = ofolder
  ofolder = output.hdfs.path

  jobname = "gwas.maxT.perm.findmax.step2"
  z = rhmr(
    jobname=jobname,
    setup=setup, 
    map=map,
    reduce=reduce, 
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    orderby="integer",
    mapred = list(
      mapred.reduce.tasks=1,
      mapred.task.timeout=ONEMIN*minutes.until.timeout,
      rhipe_map_buffsize=RHIPE_MAP_BUFFSIZE,
      rhipe_reduce_buffsize=RHIPE_REDUCE_BUFFSIZE,
      mapred.textoutputformat.usekey=T,
      mapred.field.separator="\t",
      mapred.textoutputformat.separator="\t"
    )
  )

  rhex(z, async=F)

}

gwas.perm.broadcast <- function(
  genotype.hdfs.path,
  output.hdfs.path,
  n.copies=200,
  minutes.until.timeout=10
) {

  rhinit.singleton()

  setup = expression({
    suppressPackageStartupMessages(library(BlueSNP))
    n.copies = N_COPIES
  })

  setup = expressionBuilder(setup, 
    N_COPIES=deparse(n.copies)
  )

  map = expression({
    rhcounter("PROGRESS", "_TASK_", 1)

    for (i in seq_along(map.values)) {  # each snp record
      rhcounter("PROGRESS", "_IN_", 1)
      key = map.keys[[i]]
      value = map.values[[i]]
      
      rsid = value$rsid
      
      # put the counter in broadcast mode
      value$thecount = broadcast(value$thecount)
      
      if (!is.finished(value$thecount)) {
        rhcounter("PROGRESS", "_IS_NOT_FINISHED_", 1)
        
        for (j in 1:n.copies) {  # broadcast
          rhcollect(j, value)  # key on copy number 1, 2, ..., n.copies
          rhcounter("PROGRESS", "_OUT_", 1)
        }
      }
    }
  })

  # write N copies of the same output file
  reduce = expression(
    pre={
      rhcounter("PROGRESS", "_TASK_", 1)
      rhstatus(paste("Working on key:", reduce.key))
    },
    reduce={
      for (i in seq_along(reduce.values)) {
        rhcounter("PROGRESS", "_IN_", 1)
        value = reduce.values[[i]]
        rsid = value$rsid
        rhcollect(rsid, value)  # key on rsid
        rhcounter("PROGRESS", "_OUT_", 1)
      }
    }
  )

  inout = c("sequence", "sequence")
  ifolder = genotype.hdfs.path
  ofolder = output.hdfs.path
  
  jobname = "gwas.perm.broadcast"
  z = rhmr(
    jobname=jobname,
    setup=setup, 
    map=map,
    reduce=reduce, 
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    orderby="integer",
    partitioner=list(lims=1, type="integer"),
    mapred = list(
      mapred.reduce.tasks=n.copies,
      mapred.task.timeout=ONEMIN*minutes.until.timeout,
      rhipe_map_buffsize=RHIPE_MAP_BUFFSIZE,
      rhipe_reduce_buffsize=RHIPE_REDUCE_BUFFSIZE
    )
  )

  rhex(z, async=F)

}

gwas.perm.collect <- function(
  input.hdfs.path,
  output.hdfs.path,
  minutes.until.timeout=10
  ) {

  # ################################################################################
  # Collect multiple permutation records into a single permutation record
  # ################################################################################

  rhinit.singleton()

  # new setup format
  setup = expression(
    reduce={
      suppressPackageStartupMessages(library(BlueSNP))
    }
  )

  map = identity.map
  reduce = reduce.collect

  inout = c("sequence", "sequence")
  ifolder = input.hdfs.path
  ofolder = output.hdfs.path

  jobname = "gwas.perm.collect"
  z = rhmr(
    jobname=jobname,
    setup=setup,
    map=map,
    reduce=reduce,
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    orderby="character",
    partitioner=list(lims=1, type="string"),
    mapred = list(
      mapred.reduce.tasks=reduce.task.capacity(),
      mapred.task.timeout=ONEMIN*minutes.until.timeout,
      rhipe_map_buffsize=RHIPE_MAP_BUFFSIZE,
      rhipe_reduce_buffsize=RHIPE_REDUCE_BUFFSIZE
    )
  )

  rhex(z, async=F)

}

gwas.perm.report <- function(
  input.hdfs.path,
  output.hdfs.path,
  hit.report.cutoff=5,
  minutes.until.timeout=10
) {

  rhinit.singleton()

  setup = expression({
    suppressPackageStartupMessages(library(BlueSNP))
    hit.report.cutoff = HIT.REPORT.CUTOFF
  })

  setup = expressionBuilder(setup, 
    HIT.REPORT.CUTOFF=deparse(hit.report.cutoff)
  )

  map = expression({
    rhcounter("PROGRESS", "_TASK_", 1)

    for (i in seq_along(map.values)) {  # each snp record
      rhcounter("PROGRESS", "_IN_", 1)
      key = map.keys[[i]]
      value = map.values[[i]]

      # append for easy access
      value$p.value     = pval(value$thecount)
      value$hits        = hits(value$thecount)
      value$tries       = tries(value$thecount)
      value$is.finished = is.finished(value$thecount)

      fields = c(
        "phenotype.name",
        "rsid",
        "chromosome",
        "position",
        "p.value",
        "p.value.adjusted",
        "statistic.real",
        "hits",
        "tries",
        "is.finished"
      )

      new.value = value[fields]
      new.key = value$p.value  # numeric
      
      if (value$hits <= hit.report.cutoff) {  # only report if significant
        rhcollect(new.key, new.value)
        rhcounter("PROGRESS", "_OUT_", 1)
      }
    }
  })
  
  reduce = identity.reduce

  # reduce.cleanup:
  #write.table(paste(column.names, collapse="\t"),
  #  file="./tmp/header.txt",
  #  quote=F,
  #  row.names=F,
  #  col.names=F
  #)

  inout = c("sequence", "text")
  ifolder = input.hdfs.path
  ofolder = output.hdfs.path
  
  jobname = "gwas.perm.report"
  z = rhmr(
    jobname=jobname,
    setup=setup, 
    copyFiles=T,
    map=map,
    reduce=reduce, 
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    orderby="numeric",
    mapred=list(
      mapred.reduce.tasks=1,
      mapred.task.timeout=ONEMIN*minutes.until.timeout,
      rhipe_map_buffsize=RHIPE_MAP_BUFFSIZE,
      rhipe_reduce_buffsize=RHIPE_REDUCE_BUFFSIZE,
      mapred.textoutputformat.usekey=F,
      mapred.field.separator="\t",
      mapred.textoutputformat.separator="\t"
    )
  )
  
  rhex(z, async=F)
  
}

gwas.perm.run <- function(
  genotype.hdfs.path,                        # hdfs path to genotype dir
  phenotype.hdfs.path,                       # hdfs path to phenotype Rdata file (must fit in memory)
  output.hdfs.path,                          # hdfs path to results dir
  method="qt.linear.regression",             # a built-in or custom test
  statistic.name="t.statistic",              # result[[statistic.name]]
  phenotype.cols=1,                          # subset of phenotype matrix col name/number
  is.maxT=T,                                 # default is maxT mode
  is.premature.stop=F,                       # default for maxT is to NOT do a premature stop
  is.report.all.stats=T,                     # default for maxT is to report all test stats
  is.reduce=T,                               # reduce unnecessarry when SNP records not replicated
  n.permutations=1000,
  user.code=NULL,                            # hdfs path to user-defined assoc tests
  mapred.reduce.tasks=reduce.task.capacity(),  # might want fewer
  minutes.until.timeout=10,                  # override hadoop default
  job.tag=NULL
) {

  # WARNING: the value of random.seed is crucial for maxT and adaptive permutation
  # to work properly
  random.seed = NULL  # the seed must be NULL for adaptive
  if (is.maxT)
    random.seed=sample(999999999, 1)  # the seed must take a value for maxT

  # ################################################################################
  # Run the permutations, emit updated SNP records (without snp.vector to save space)
  # ################################################################################

  if (length(phenotype.cols)!=1)
    stop("we only allow for one phenotype in phenotype.cols when performing permutations")

  rhinit.singleton()
  
  # at mapper startup, these files are copied from the hdfs to the mapper local fs at ./tmp/
  shared = append.user.code.to.shared(phenotype.hdfs.path, user.code)

  setup = expression({
    suppressPackageStartupMessages(library(BlueSNP))
  
    load(PHENOTYPE_FILE)             # variable substitution
    phenotype.cols = PHENOTYPE.COLS  # variable substitution
    
    # restrict Y to just the columns we are interested in
    # WARNING: output column number no longer corresponds to input column number
    Y = column.select(Y, phenotype.cols)
    phenotype.cols = 1:ncol(Y)  # redefine. overwrites NULL
    
    # phenotype.names default to colnames(), fallback to col numbers 
    # WARNING: phenotype.names[j] is the jth entry of the selected cols
    phenotype.names = colnames(Y)
    if (is.null(phenotype.names))
      phenotype.names = phenotype.cols
  })
  
  # expressionBuilder() performs variable substitution on ALL_CAPS
  setup = expressionBuilder(setup, 
    PHENOTYPE_FILE=deparse(stripPath(phenotype.hdfs.path)),
    PHENOTYPE.COLS=deparse(phenotype.cols)
  )
  setup = append.user.code.to.setup(setup, user.code)

  # ################################################################################

  map = expression({
    method              = METHOD               # variable substitution
    statistic.name      = STATISTIC.NAME       # variable substitution
    n.permutations      = N.PERMUTATIONS       # variable substitution
    random.seed         = RANDOM.SEED          # variable substitution
    is.premature.stop   = IS.PREMATURE.STOP    # variable substitution
    is.report.all.stats = IS.REPORT.ALL.STATS  # variable substitution
    
    rhcounter("PROGRESS", "_TASK_", 1)
    
    for (i in seq_along(map.values)) {  # each snp record
      rhcounter("PROGRESS", "_IN_", 1)
      key = map.keys[[i]]
      value = map.values[[i]]

      if (is.null(value$thecount))  # initialize the counter if it is absent (first time)
        value$thecount = PermutationCounter()

      if (is.finished(value$thecount)) {  # skip this record if it is finished
        # this check lets us broadcast fewer times
        rhcollect(key, value)
        rhcounter("PROGRESS", "_OUT_", 1)
        next
      }
      # if we made it this far, this record is not finished

      chromosome = value$chromosome
      rsid       = value$rsid
      distance   = value$distance
      position   = value$position
      x          = value$snp.vector

      statistic.real = eval(call(method, Y, x))[[statistic.name]]

      result = permutation.loop(
        thecount=value$thecount,
        method, 
        statistic.name, 
        Y, 
        x, 
        statistic.real, 
        n.permutations, 
        keepalive=i, 
        random.seed=random.seed, 
        is.premature.stop=is.premature.stop,
        is.report.all.stats=is.report.all.stats
      )

      new.value = value
      new.value$thecount       = value$thecount + result$thecount  # value$thecount in broadcast mode
      new.value$statistic.real = statistic.real
      if (is.report.all.stats)
        new.value$statistic.random = result$statistic.random
      new.value$phenotype.name = phenotype.names  # should be just one phenotype name

      # emit snp record
      rhcollect(rsid, new.value)
      rhcounter("PROGRESS", "_OUT_", 1)
    }
  })

  map = expressionBuilder(map, 
    METHOD=deparse(method),
    STATISTIC.NAME=deparse(statistic.name),
    N.PERMUTATIONS=deparse(n.permutations),
    RANDOM.SEED=deparse(random.seed),
    IS.PREMATURE.STOP=deparse(is.premature.stop),
    IS.REPORT.ALL.STATS=deparse(is.report.all.stats)
  )

  # ################################################################################

  reduce.setup = expression({
    suppressPackageStartupMessages(library(BlueSNP))
  })

  reduce = reduce.collect

  # ################################################################################
  
  if (!is.reduce)
    mapred.reduce.tasks=0

  inout = c("sequence", "sequence")
  ifolder = genotype.hdfs.path
  ofolder = output.hdfs.path

  jobname = "gwas.perm.run"
  if (!is.null(job.tag))
    jobname = paste(jobname, job.tag, sep="-")
  
  # new setup format
  setup = as.expression(list(map=setup[[1]], reduce=reduce.setup[[1]]))
  
  z = rhmr(
    jobname=jobname,
    setup=setup,
    map=map,
    reduce=reduce,
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    shared=shared,
    orderby="character",
    partitioner=list(lims=1, type="string"),
    mapred = list(
      mapred.reduce.tasks=mapred.reduce.tasks,
      mapred.task.timeout=ONEMIN*minutes.until.timeout,
      rhipe_map_buffsize=RHIPE_MAP_BUFFSIZE,
      rhipe_reduce_buffsize=RHIPE_REDUCE_BUFFSIZE
    )
  )
    
  rhex(z, async=F)

}

gwas.sparse.report <- function(
  input.hdfs.path,
  output.hdfs.path,
  statistic.name="p.value",
  phenotype.number.offset=0,  # in case we did batches of phenotypes
  bluesnp.code.hdfs.path="/BlueSNP/BlueSNP_core.R",  # where the BlueSNP core codebase is located
  user.code.hdfs.path="/BlueSNP/do_not_delete.R",    # where (optional) user-defined functions are located
  rhipe_map_buffsize=100,                           # number of records per batch **250MB Rhipe limit**
  minutes.until.timeout=5,                           # override Hadoop default timeout
  mapred.reduce.tasks=1
) {

  # generate list report (sparse matrix) from gwas(is.sparse.output=T)

  require(Rhipe)
  rhinit.singleton()

  shared = c(bluesnp.code.hdfs.path, user.code.hdfs.path)
  
  setup = expression({
    source(BLUESNP_CODE)
    source(USER_CODE)
    phenotype.number.offset = PHENOTYPE.NUMBER.OFFSET
    statistic.name = STATISTIC.NAME 
  })
  
  setup = expressionBuilder(setup, 
    BLUESNP_CODE=deparse(stripPath(bluesnp.code.hdfs.path)),
    USER_CODE=deparse(stripPath(user.code.hdfs.path)),
    PHENOTYPE.NUMBER.OFFSET = deparse(phenotype.number.offset),
    STATISTIC.NAME=deparse(statistic.name)
  )

  # example keys:
  # "rs564002" "n.individuals"
  # "rs564002" "df"           
  # "rs564002" "beta"         
  # "rs564002" "se"           
  # "rs564002" "t.statistic"  
  # "rs564002" "p.value"

  map = expression({
    rhcounter("PROGRESS", "_TASK_", 1)

    for (i in seq_along(map.values)) {
      rhcounter("PROGRESS", "_IN_", 1)
      key = map.keys[[i]]
      value = map.values[[i]]
      
      key1 = key[1]  # "rs564002"
      key2 = key[2]  # "p.value"
      
      if (key2==statistic.name) {  # this is a "p.value" record
      
        phenotype.number = value$phenotype.number + phenotype.number.offset
        statistic.value = value$statistic.value
      
        new.key = c(key1, as.character(phenotype.number))  # for sorting
#        new.value = c(key1, phenotype.number, statistic.value)
        new.value = c(key1, phenotype.name, statistic.value)
        
        rhcollect(new.key, new.value)
        rhcounter("PROGRESS", "_OUT_", 1)

      }
    }
  })
  
  reduce = identity.reduce

  inout = c("sequence", "text")
  ifolder = input.hdfs.path
  ofolder = output.hdfs.path
  
  jobname = "gwas.sparse.report"

  z = rhmr(
    jobname=jobname,
    setup=setup, 
    copyFiles=T,
    map=map,
    reduce=reduce, 
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    shared=shared,
    orderby="character",
    mapred=list(
      mapred.reduce.tasks=mapred.reduce.tasks,
      mapred.task.timeout=ONEMIN,
      rhipe_map_buffsize=rhipe_map_buffsize,
      mapred.textoutputformat.usekey=F,
      mapred.field.separator="\t",
      mapred.textoutputformat.separator="\t"
    )
  )
  
  rhex(z, async=F)
  
}

# read.plink.tfam() runs LOCALLY on the master, but reads/writes from/to the HDFS
read.plink.tfam <- function(
  tfam.hdfs.path,    # space-delimited tped as generated by PLINK
  output.hdfs.path,  # must end in .RData
  is.cleanup=T,      # delete ./tmp/
  is.quiet=T         # don't return the matrix to the console
) {

  rhinit.singleton()

  # get from hdfs
  LOCAL = "./tmp"
  cat("[BlueSNP] copy from HDFS", tfam.hdfs.path, "to", LOCAL, "\n")
  if (!file.exists(LOCAL)) { dir.create(LOCAL, recursive=T) }
  rhget(tfam.hdfs.path, LOCAL)
  
  local.file = paste(LOCAL, "/", stripPath(tfam.hdfs.path), sep="")

  # assume tfam file fits in memory
  d = read.table(local.file)

  # relevant columns
  iid = as.character(d[,2])  # individual id
  Y = as.matrix(d[,-c(1:5)]) # phenotype matrix

  rownames(Y) = iid
  colnames(Y) = paste("trait", 1:(ncol(d)-5), sep="")

  outfile = stripPath(output.hdfs.path)
  cat("[BlueSNP] saving local file: ", outfile, "\n")
  save(file=outfile, list=c("Y"))

  cat("[BlueSNP] copy from", stripPath(outfile)," to HDFS", output.hdfs.path, "\n")
  rhput(outfile, output.hdfs.path)

  if (is.cleanup) {
    cat("[BlueSNP] removing", LOCAL, "\n")
    system(paste("rm -r", LOCAL))
  }

  if (!is.quiet)
    Y

}
read.plink.tped <- function(
  tped.hdfs.path,            # space-delimited tped file, or directory of tped files
  output.hdfs.path,          # where to write the output SNP records
  mapred.reduce.tasks=0,     # manually control the numnber of output files (splits)
  minutes.until.timeout=10   # override Hadoop default timeout
) {

  jobname = "read.plink.tped"
  rhinit.singleton()

  map = expression({
    rhcounter("PROGRESS", "_TASK_", 1)

    for (i in seq_along(map.values)) {  # each line becomes one SNP record
      rhcounter("PROGRESS", "_IN_", 1)
      key = map.keys[[i]]
      value = map.values[[i]]

      tokens  = strsplit(value, " +")[[1]]  # split on one ore more spaces

      chromosome = tokens[1]                # text
      rsid       = tokens[2]                # text
      distance   = as.integer(tokens[3])    # integer
      position   = as.integer(tokens[4])    # integer
      genotype = tokens[-seq(1, 4)]         # text

      # which is the minor allele?
      t = table(genotype)
      alleles = setdiff(names(table(genotype)), c("0","N"))  # ignore missing alleles
      t = t[alleles]
      minor.allele = NULL
      major.allele = NULL
      if (t[1] == t[2]) {  # tie
        minor.allele = names(t[1])
        major.allele = names(t[2])
      } else {
        minor.allele = names(which(t==min(t)))
        major.allele = names(which(t!=min(t)))
      }

      # encode genotype using 0,1,2 minor allele count 
      minor.allele.count = rowSums(matrix(genotype==minor.allele, ncol=2, byrow=T))
      major.allele.count = rowSums(matrix(genotype==major.allele, ncol=2, byrow=T))

# TODO: test sex chromosome
      # flag missing / incomplete genotypes
      if(length(intersect(chromosome, c("23", "24", "X", "Y"))))  # is sex chromosome
        is.missing.or.incomplete = (minor.allele.count + major.allele.count) < 1
      else
        is.missing.or.incomplete = (minor.allele.count + major.allele.count) < 2
      minor.allele.count[is.missing.or.incomplete] = NA

      new.value = list(
        chromosome = chromosome,
        rsid = rsid,
        distance = distance,
        position = position,
        snp.vector = minor.allele.count
      )

      # emit
      new.key = rsid
      rhcollect(new.key, new.value)
      rhcounter("PROGRESS", "_OUT_", 1)
    }
  })

  reduce = identity.reduce
  
  inout = c("text", "sequence")
  ifolder = tped.hdfs.path
  ofolder = output.hdfs.path

  z = rhmr(
    jobname=jobname,
    map=map,
    reduce=reduce,
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    mapred=list(
      mapred.reduce.tasks=mapred.reduce.tasks,
      mapred.task.timeout=ONEMIN*minutes.until.timeout,
      rhipe_map_buffsize=RHIPE_MAP_BUFFSIZE,
      rhipe_reduce_buffsize=RHIPE_REDUCE_BUFFSIZE
    )
  )

  rhex(z, async=F)
}

example.user.code <- function(ifolder, ofolder, user.code=NULL) {

  jobname = "user.code" 
  rhinit.singleton()
  
  setup = expression({
    suppressPackageStartupMessages(library(BlueSNP))
  })
  
  setup = append.user.code.to.setup(setup, user.code)
  shared = append.user.code.to.shared("", user.code)
  
  map = expression({
    rhcounter("PROGRESS", "_TASK_", 1)
    for (i in seq_along(map.values)) {
      rhcounter("PROGRESS", "_IN_", 1)
      rhstatus(paste("Working on key:", map.keys[[i]]))
      value = myfunction(sample(100, 20))  # user-defined
      rhcollect(map.keys[[i]], value)
      rhcounter("PROGRESS", "_OUT_", 1)
    }
  })
  
  reduce = identity.reduce
  
  inout = c("text", "sequence")
  
  z = rhmr(
    jobname=jobname,
    setup=setup,
    shared=shared,
    map=map,
    reduce=reduce,
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    mapred=list(
      mapred.map.tasks=map.task.capacity(),
      mapred.reduce.tasks=reduce.task.capacity(),
      mapred.task.timeout=ONEMIN
    )
  )
  
  rhex(z, async=F)
}
filter.by.keys <- function(
  ifolder, 
  ofolder,
  mykeys, # c("key1", "key2", ...)
  inout=c("sequence", "sequence"),
  split.factor=1
) {

  mapred.min.split.size=128*1024*1024*split.factor

  rhinit.singleton()

  setup = expression({
    suppressPackageStartupMessages(library(BlueSNP))
    mykeys = MYKEYS
  })

  setup = expressionBuilder(setup, 
    MYKEYS=paste(deparse(mykeys), collapse="")  # TODO: paste() required for vector
  )

  map = expression({
    rhcounter("PROGRESS", "_TASK_", 1)
    for (i in seq_along(map.values)) {
      rhcounter("PROGRESS", "_IN_", 1)
      key = map.keys[[i]]
      value = map.values[[i]]

      if (sum(key==mykeys)) {  # key is on the list
        rhcollect(key, value)
        rhcounter("PROGRESS", "_OUT_", 1)
      }
    }
  })
  
  reduce = identity.reduce

  jobname = "filter.by.keys"
  z = rhmr(
    jobname=jobname,
    setup=setup,
    map=map,
    reduce=reduce,
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    shared=shared,
    mapred = list(
      mapred.map.tasks=map.task.capacity(),
      mapred.reduce.tasks=reduce.task.capacity(),
      mapred.task.timeout=ONEMIN*minutes.until.timeout,
      rhipe_map_buffsize=RHIPE_MAP_BUFFSIZE,
      rhipe_reduce_buffsize=RHIPE_REDUCE_BUFFSIZE,
      mapred.min.split.size=mapred.min.split.size
    )
  )

  rhex(z, async=F)

}

identityMR <- function(ifolder, ofolder, user.code=NULL) {

  jobname = "identityMR" 
  rhinit.singleton()
  
  setup = expression({
    suppressPackageStartupMessages(library(BlueSNP))
  })
  
  setup = append.user.code.to.setup(setup, user.code)
  shared = append.user.code.to.shared("", user.code)
  
  map = identity.map
  reduce = identity.reduce
  
  inout = c("text", "sequence")
  
  z = rhmr(
    jobname=jobname,
    setup=setup,
    shared=shared,
    map=map,
    reduce=reduce,
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    mapred=list(
      mapred.map.tasks=map.task.capacity(),
      mapred.reduce.tasks=reduce.task.capacity(),
      mapred.task.timeout=ONEMIN
    )
  )
  
  rhex(z, async=F)
}
splits <- function(
  A.hdfs.path,
  B.hdfs.path,
  n.splits=map.task.capacity(),
  minutes.until.timeout=10
) {

  rhinit.singleton()

  map = identity.map
  reduce = identity.reduce

  inout = c("sequence", "sequence")
  ifolder = A.hdfs.path
  ofolder = B.hdfs.path

  jobname = "splits"
  z = rhmr(
    jobname=jobname,
    map=map,
    reduce=reduce,
    inout=inout,
    ifolder=ifolder,
    ofolder=ofolder,
    mapred = list(
      mapred.reduce.tasks=n.splits,
      mapred.task.timeout=ONEMIN*minutes.until.timeout,
      rhipe_map_buffsize=RHIPE_MAP_BUFFSIZE,
      rhipe_reduce_buffsize=RHIPE_REDUCE_BUFFSIZE
    )
  )

  rhex(z, async=F)

}
cc.allelic <- function(y, x) {
  # y is phenotype vector {0,1} = {control,case} or {1,2} = {control,case}
  # x is genotype {0,1,2} = number of copies minor allele

  # trick to return output var names when function is called with no params
  if (nargs()==0) {  # called with no params
    y = sample(0:1, 100, replace=T)  # dummy data
    x = sample(0:2, 100, replace=T)
    return(names(cc.allelic(y, x)))
  }

  # select elements with values
  is = !is.na(x) & !is.na(y)  
  x = x[is]
  y = y[is]

  # accept {1,2} instead of {0,1} labels
  if (max(y) > 1) {
    if (max(y)==2) {
      y = y - 1
    } else {
      stop("case-control phenotype must be encoded as {1,0} or {2,1}")
    }
  }

  x = as.factor(x)
  levels(x) = c(0,1,2)
  con = table(y, x)

  m = cbind(con[,1]*2+con[,2], con[,2]+con[,3]*2)
  t = chisq.test(m, correct=F)
  chisq = as.numeric(t$statistic)
  pval = as.numeric(t$p.value)
  or = as.numeric(m[2,2]*m[1,1] / m[2,1] / m[1,2])

  list(n.individuals=as.numeric(sum(is)), chi.sq=chisq, odds.ratio=or, p.value=pval)
}
cc.dominant <- function(y, x) {
  # y is phenotype vector {0,1} = {control,case} or {1,2} = {control,case}
  # x is genotype {0,1,2} = number of copies minor allele

  # trick to return output var names when function is called with no params
  if (nargs()==0) {  # called with no params
    y = sample(0:1, 100, replace=T)  # dummy data
    x = sample(0:2, 100, replace=T)
    return(names(cc.dominant(y, x)))
  }

  # select elements with values
  is = !is.na(x) & !is.na(y)  
  x = x[is]
  y = y[is]

  # accept {1,2} instead of {0,1} labels
  if (max(y) > 1) {
    if (max(y)==2) {
      y = y - 1
    } else {
      stop("case-control phenotype must be encoded as {1,0} or {2,1}")
    }
  }

  x = as.factor(x)
  levels(x) = c(0,1,2)

  con = table(y, x)
  m = cbind(con[,1], con[,2]+con[,3])
  t = chisq.test(m, correct=F)
  chisq=as.numeric(t$statistic)
  pval= as.numeric(t$p.value)

  list(chi.sq=chisq, df=1, p.value=pval)
}
cc.genotypic <- function(y, x) {
  # y is phenotype vector {0,1} = {control,case} or {1,2} = {control,case}
  # x is genotype {0,1,2} = number of copies minor allele

  # trick to return output var names when function is called with no params
  if (nargs()==0) {  # called with no params
    y = sample(0:1, 100, replace=T)  # dummy data
    x = sample(0:2, 100, replace=T)
    return(names(cc.genotypic(y, x)))
  }

  # select elements with values
  is = !is.na(x) & !is.na(y)  
  x = x[is]
  y = y[is]

  # accept {1,2} instead of {0,1} labels
  if (max(y) > 1) {
    if (max(y)==2) {
      y = y - 1
    } else {
      stop("case-control phenotype must be encoded as {1,0} or {2,1}")
    }
  }

  x = as.factor(x)
  levels(x) = c(0,1,2)

  con = table(y, x)

  t     = NA
  chisq = NA
  pval  = NA
  df    = NA

  tryCatch({
    t = chisq.test(con, correct=F)
    chisq = as.numeric(t$statistic)
    pval = as.numeric(t$p.value)
    df = 2
  }, warning = function(w) {
    t = NA
    chisq = NA
    df = NA
    pval = NA
  })


  # return a list
  list(n.individuals=as.numeric(sum(is)), chi.sq=chisq, df=df, p.value=pval)
}
cc.logistic.regression <- function(y, x) {
  # y is phenotype vector {0,1} = {control,case} or {1,2} = {control,case}
  # x is genotype {0,1,2} = number of copies minor allele

  # trick to return output var names when function is called with no params
  if (nargs()==0) {  # called with no params
    y = sample(0:1, 100, replace=T)  # dummy data
    x = sample(0:2, 100, replace=T)
    return(names(cc.logistic(y, x)))
  }

  # select elements with values
  is = !is.na(x) & !is.na(y)  
  x = x[is]
  y = y[is]

  # accept {1,2} instead of {0,1} labels
  if (max(y) > 1) {
    if (max(y)==2) {
      y = y - 1
    } else {
      stop("case-control phenotype must be encoded as {1,0} or {2,1}")
    }
  }

  m = glm(y ~ x, family="binomial")
  or = exp(summary(m)$coefficients[2,1])
  stat = summary(m)$coefficients[2,3]
  pval = summary(m)$coefficients[2,4]

  #list(STAT=stat, OR=or, P=pval)  # plink name
  list(n.individuals=as.numeric(sum(is)), stat=stat, odds.ratio=or, p.value=pval)
}
cc.recessive <- function(y, x) {
  # y is phenotype vector {0,1} = {control,case} or {1,2} = {control,case}
  # x is genotype {0,1,2} = number of copies minor allele

  # trick to return output var names when function is called with no params
  if (nargs()==0) {  # called with no params
    y = sample(0:1, 100, replace=T)  # dummy data
    x = sample(0:2, 100, replace=T)
    return(names(cc.recessive(y, x)))
  }

  # select elements with values
  is = !is.na(x) & !is.na(y)  
  x = x[is]
  y = y[is]

  # accept {1,2} instead of {0,1} labels
  if (max(y) > 1) {
    if (max(y)==2) {
      y = y - 1
    } else {
      stop("case-control phenotype must be encoded as {1,0} or {2,1}")
    }
  }

  x = as.factor(x)
  levels(x) = c(0,1,2)

  con = table(y, x)
  m = cbind(con[,1]+con[,2], con[,3])

  t     = NA
  chisq = NA
  pval  = NA
  df    = NA

  tryCatch({
    t = chisq.test(m, correct=F)
    chisq = as.numeric(t$statistic)
    pval = as.numeric(t$p.value)
    df = 1
  }, warning = function(w) {
    t = NA
    chisq = NA
    df = NA
    pval = NA
  })

  list(chi.sq=chisq, df=df, p.value=pval)
}
cc.trend <- function(y, x) {
  # y is phenotype vector {0,1} = {control,case} or {1,2} = {control,case}
  # x is genotype {0,1,2} = number of copies minor allele

  # trick to return output var names when function is called with no params
  if (nargs()==0) {  # called with no params
    y = sample(0:1, 100, replace=T)  # dummy data
    x = sample(0:2, 100, replace=T)
    return(names(cc.trend(y, x)))
  }

  # select elements with values
  is = !is.na(x) & !is.na(y)  
  x = x[is]
  y = y[is]

  # accept {1,2} instead of {0,1} labels
  if (max(y) > 1) {
    if (max(y)==2) {
      y = y - 1
    } else {
      stop("case-control phenotype must be encoded as {1,0} or {2,1}")
    }
  }

  x = as.factor(x)
  levels(x) = c(0,1,2)

  t = c(0, 1, 2)
  con = table(y, x)

  R = apply(con, 1, sum)
  C = apply(con, 2, sum)
  N = sum(R)
  Tstat = R[2]*sum(t*con[1,])-R[1]*sum(t*con[2,])
  VAR = R[1]*R[2]/N*(sum(t^2*C*(N-C))-2*(t[1]*t[2]*C[1]*C[2]+t[1]*t[3]*C[1]*C[3]+t[2]*t[3]*C[2]*C[3]))
  chisq = Tstat^2 / VAR
  pval = pchisq(chisq, 1, low=F)
  
  names(chisq) = NULL
  names(pval) = NULL

  list(chi.sq=chisq, df=1, p.value=pval)
}
qt.linear.regression <- function(y, x) {

  # trick to return output var names when function is called with no params
  if (nargs()==0) {  # called with no params
    return(names(qt.linear.regression(1:10, 2:11)))  # dummy data
  }
  
  # select elements with values
  is = !is.na(x) & !is.na(y)  
  x = x[is]
  y = y[is]

  df2 = sum(is) - 2

  cov.yx = cov(y, x)
  cov.xx = var(x)
  cov.yy = var(y)

  beta = cov.yx / cov.xx
  se = sqrt(cov.yy / cov.xx - cov.yx^2 / cov.xx / cov.xx) / sqrt(df2)
  t.stat = beta / se
  
  r2 = cov.yx^2 / cov.xx / cov.yy

  p = pt(abs(t.stat), df2, lower.tail=F) * 2

  #list(NMISS=sum(is), BETA=beta, SE=se, R2=r2, T=t.stat, P=p)  # plink names
  list(n.individuals=as.numeric(sum(is)), beta=beta, se=se, R2=r2, t.statistic=t.stat, p.value=p)  # BlueSNP names
  # BUG: Rhipe has a problem exporting NA integers, so we convert n.individuals to a numeric type
}
# PermutationCounter S3 object
# Robert Prill  rjprill@us.ibm.com  12-15-2011


# ##################################################
# generic method

PermutationCounter <- function(x, ...)
  UseMethod("PermutationCounter")


# ##################################################
# constructor

PermutationCounter.default <- function(hits=0, tries=0, 
  previous.hits=0, previous.tries=0, limit=5) {
  obj = list(
    hits = hits,
    tries = tries,
    previous.hits = previous.hits,    # all the hits we know about
    previous.tries = previous.tries,  # all the tries we know about
    limit = limit                     # see is.finished()
  )
  class(obj) <- "PermutationCounter"
  obj
}


# ##################################################
# getter methods

hits.PermutationCounter <- function(x)
  x[["hits"]]

tries.PermutationCounter <- function(x)
  x[["tries"]]

previous.hits.PermutationCounter <- function(x)
  x[["previous.hits"]]

previous.tries.PermutationCounter <- function(x)
  x[["previous.tries"]]


# ##################################################
# virtual attribute getter methods

is.finished.PermutationCounter <- function(x) 
  (x[["previous.hits"]] + x[["hits"]]) > x[["limit"]]

pval.PermutationCounter <- function(x) {
  #(x[["previous.hits"]] + x[["hits"]] + 1) / (x[["previous.tries"]] + x[["tries"]] + 1)
  # only base the pval on hits and tries.  
  # previous.hits and previous.tries only support an early termination
  (x[["hits"]] + 1) / (x[["tries"]] + 1)
}

# ##################################################
# setter methods

"hits<-.PermutationCounter" <- function(x, value) {
  x[["hits"]] <- value
  x
}

"tries<-.PermutationCounter" <- function(x, value) {
  x[["tries"]] <- value
  x
}

"previous.hits<-.PermutationCounter" <- function(x, value) {
  x[["previous.hits"]] <- value
  x
}

"previous.tries<-.PermutationCounter" <- function(x, value) {
  x[["previous.tries"]] <- value
  x
}


# ##################################################
# math operations

# addition
"+.PermutationCounter" <- function(x, y) {
  # validation
  #if (x[["previous.hits"]] != y[["previous.hits"]] | x[["previous.tries"]] != y[["previous.tries"]])
  #  stop("Can only add PermutationCounter objects if previous.hits and previous.tries are the same in both counters.")

  x[["hits"]]  <- x[["hits"]]  + y[["hits"]]
  x[["tries"]] <- x[["tries"]] + y[["tries"]]
  x
}

# subtraction
"-.PermutationCounter" <- function(x, y) {
  # validation
  #if (x[["previous.hits"]] != y[["previous.hits"]] | x[["previous.tries"]] != y[["previous.tries"]])
  #  stop("Can only subtract PermutationCounter objects if previous.hits and previous.tries are the same in both counters.")

  x[["hits"]]  <- x[["hits"]]  - y[["hits"]]
  x[["tries"]] <- x[["tries"]] - y[["tries"]]
  x
}


# ##################################################
# more methods

increment.hit.PermutationCounter <- function(x) {
  # handle validation that previous.hits and previous.tries must match
  y = x
  y[["hits"]]  = 1
  y[["tries"]] = 1
  
  x + y
}

increment.miss.PermutationCounter <- function(x) {
  #x + PermutationCounter.default(0, 1, 0, 0)
  y = x
  y[["hits"]]  = 0
  y[["tries"]] = 1
  x + y
}

broadcast.PermutationCounter <- function(x) {
  total.hits  = x[["hits"]]  + x[["previous.hits"]]
  total.tries = x[["tries"]] + x[["previous.tries"]]
  PermutationCounter.default(0, 0, total.hits, total.tries)
}

# ##################################################
# presentation

summary.PermutationCounter <- function(x) {
  data.frame(
    is.finished  = is.finished.PermutationCounter(x),
    p.value      = pval.PermutationCounter(x),
    hits         = hits.PermutationCounter(x),
    tries        = tries.PermutationCounter(x),
    previous.hits  = previous.hits.PermutationCounter(x),
    previous.tries = previous.tries.PermutationCounter(x)
  )
}


# ##################################################
# generic methods (i.e., objected-oriented polymorphism)

hits <- function(x, ...)
  UseMethod("hits", x)

tries <- function(x, ...)
  UseMethod("tries", x)

previous.hits <- function(x, ...)
  UseMethod("previous.hits", x)

previous.tries <- function(x, ...)
  UseMethod("previous.tries", x)

is.finished <- function(x, ...) 
  UseMethod("is.finished", x)

pval <- function(x, ...)
  UseMethod("pval", x)
  
increment.hit <- function(x, ...)
  UseMethod("increment.hit", x)

increment.miss <- function(x, ...)
  UseMethod("increment.miss", x)
  
"hits<-" <- function(x, ...)
  UseMethod("hits<-", x)

"tries<-" <- function(x, ...)
  UseMethod("tries<-", x)

"previous.hits<-" <- function(x, ...)
  UseMethod("previous.hits<-", x)

"previous.tries<-" <- function(x, ...)
  UseMethod("previous.tries<-", x)
  
broadcast <- function(x, ...)
  UseMethod("broadcast", x)

# addition and subtraction generic methods already exist

# see method list using:
# methods(class=PermutationCounter)


column.select <- function(
  X,         # matrix or data.frame
  cols=NULL  # column numbers or names
) {
  
  if (is.null(cols)) {
    return(X)  # nothing to select
  }
  
  if (is.null(ncol(X))) {
    if (cols!=1) {  # a vector input has one col
      stop("Invalid column number specified for vector input")
    }
    return(as.matrix(X, ncol=1))  # nothing to select, reformat at matrix
  }
  
  if (is.numeric(cols)) {
    invalid.cols = setdiff(cols, 1:ncol(X))
    if (length(invalid.cols)) {
      stop(paste("Invalid column numbers specified:", paste(invalid.cols, sep=", ")))
    }
    return(as.matrix(X[,cols], ncols=length(cols)))
  }
  
  if (is.character(cols)) {
    invalid.cols = setdiff(cols, colnames(X))
    if (length(invalid.cols)) {
      stop(paste("Invalid column names specified:", paste(invalid.cols, sep=", ")))
    }
    return(as.matrix(X[,cols], ncols=length(cols)))
  }
  
  # should never get this far
  stop("There was a problem selecting columns by name/number.")
}
environment.variable <- function(name, myclass="integer") {
  as(Sys.getenv(name), myclass)
}
map.task.capacity <- function(manual=NULL) {
  N = 0
  if (is.null(manual)) {  # manual is blank

    n = environment.variable("BLUESNP_MAP_TASK_CAPACITY")  # .bashrc
    if (!is.na(n))  # use env var
      N = n
    else
      N = 5  # default

  } else {  # use manual
    N = manual
  }

  N
}
onemin <- function() {
  as.integer(60000)  # ms
}
pick.copies <- function(n) {
  if (n <= 1E6)
    100
  else if (n <= 1E7)
    500
  else if (n <= 1E8)
    1000
}
pick.permutations <- function(n) {
  if (n <= 1E6)
    3000
  else if (n <= 1E7)
    6000
  else if (n <= 1E8)
    10000
}
reduce.task.capacity <- function(manual=NULL) {
  N = 0
  if (is.null(manual)) {  # manual is blank

    n = environment.variable("BLUESNP_REDUCE_TASK_CAPACITY")  # .bashrc
    if (!is.na(n))  # use env var
      N = n
    else
      N = 2  # default

  } else {  # use manual
    N = manual
  }

  N
}
stripPath <- function(txt) {
  # IN:  /the/full/path/file.txt
  # OUT: file.txt
  tail(strsplit(txt,"/")[[1]],1)
}
identity.map = expression({
  rhcounter("PROGRESS", "_TASK_", 1)
  for (i in seq_along(map.values)) {
    rhcounter("PROGRESS", "_IN_", 1)
    rhstatus(paste("Working on key:", map.keys[[i]]))
    rhcollect(map.keys[[i]], map.values[[i]])
    rhcounter("PROGRESS", "_OUT_", 1)
  }
})
identity.reduce = expression(
  pre={
    rhcounter("PROGRESS", "_TASK_", 1)
    rhstatus(paste("Working on key:", reduce.key))
  },
  reduce={
    for (i in seq_along(reduce.values)) {
      rhcounter("PROGRESS", "_IN_", 1)
      rhcollect(reduce.key, reduce.values[[i]])
      rhcounter("PROGRESS", "_OUT_", 1)
    }
  }
)
reduce.collect = expression(
  pre = {
    rhcounter("PROGRESS", "_TASK_", 1)
    value = NULL
    new.value = NULL
  },
  reduce = {
    for (i in seq_along(reduce.values)) {
      rhcounter("PROGRESS", "_IN_", 1)
      value = reduce.values[[i]]
      
      if (is.null(new.value)) {  # first time
        new.value = value
        next
      }
      # if we got this far, this is not the first time
      
      # update value
      new.value$thecount = new.value$thecount + value$thecount
      if (!is.null(new.value$statistic.random))
        new.value$statistic.random = c(new.value$statistic.random, value$statistic.random)
    }
  },
  post = {
    if(is.finished(new.value$thecount)) {  # if we're done
      new.value = new.value[setdiff(names(value), "snp.vector")] # remove snp.vector to save space
    } else {
      rhcounter("PROGRESS", "_IS_NOT_FINISHED_", 1)  # counter
    }
    
    # emit
    rhcollect(reduce.key, new.value)
    rhcounter("PROGRESS", "_OUT_", 1)
  }
)

append.user.code.to.setup <- function(setup, user.code) {
  if (!is.null(user.code)) {
    text = paste(deparse(setup[[1]]), collapse="\n")
    text = sub("^\\{","", text)
    text = sub("\\}$","", text)
    text = paste(text, "source(\"", stripPath(user.code), "\")\n", sep="")
    text = paste("{", text, sep="\n")
    text = paste(text, "}", sep="\n")
    parse(text=text, srcfile=NULL)
  } else {
    setup
  }
}

append.user.code.to.shared <- function(shared, user.code) {
  if (!is.null(user.code)) {
    c(shared, user.code)
  } else {
    shared
  }
}
expressionBuilder <- function(logic, ...) {
  
  # USEAGE: .variable.substitution("val=VAL", VAL=5) --> "val=5"
  .variable.substitution <- function(content, ...) {
    ARGS = unlist(list(...))
    if (!is.null(ARGS)) {
      for (i in 1:length(ARGS)) {
        content = gsub(names(ARGS)[i], ARGS[i], content)
      }
    }
    content
  }

  if (is.null(logic))
    stop("logic=expression() is required")

  if (class(logic)!="expression")
    stop("logic=expression() is required")

  new.logic = NULL

  if (!is.null(logic$pre) || 
    !is.null(logic$reduce) || 
    !is.null(logic$post)) {  
    # if logic has these parts, it is a REDUCE expression

    # convert to text
    pre    = paste(deparse(logic$pre), collapse="\n")
    reduce = paste(deparse(logic$reduce), collapse="\n")
    post   = paste(deparse(logic$post), collapse="\n")

    # substitute val=VAL --> val=5
    pre    = .variable.substitution(pre, ...)
    reduce = .variable.substitution(reduce, ...)
    post   = .variable.substitution(post, ...)

    # convert to expression
    pre    = parse(text=pre, srcfile=NULL)
    reduce = parse(text=reduce, srcfile=NULL)
    post   = parse(text=post, srcfile=NULL)

    # rebuild overall expression
    new.logic = as.expression(list(pre=pre[[1]], reduce=reduce[[1]], post=post[[1]]))
    
  } else {  # logic is a MAP expression
    
    content = paste(deparse(logic[[1]]), collapse="\n")
    content = .variable.substitution(content, ...)
    new.logic = parse(text=content, srcfile=NULL)
    
  }

  new.logic
}

# ##################################################
# tests

#logic = expression(pre = {
#    hello
#}, reduce = {
#    a = 1
#    b = 2
#    c = a + b
#}, post = {
#    c
#})
#
#expressionBuilder(logic, hello=555)
#
#logic = expression({
#    a = 1
#    b = 2
#    C = a + b
#})
#
#expressionBuilder(logic, C="ccc")

getKeys <- function(records) {
  do.call("rbind", lapply(records, "[[", 1)) 
}
getValues <- function(records) {
  lapply(records, "[[", 2)
}
peek <- function(hdfs.path, max=10) {
  rhinit.singleton()
  
  records <<- rhread(hdfs.path, max=max)
  keys <<- getKeys(records)
  values <<- getValues(records)
  key <<- keys[[1]]
  value <<- values[[1]]
  
  names(value)
}
pretty.task.id <- function(prefix="") {
  x = Sys.getenv("mapred.task.id")
  n = strsplit(x, "_")[[1]][5]
  paste(prefix, n, sep="")
}
# calls Rhips::rhinit() if needed and sets hdfs.setwd()
rhinit.singleton <- function(...) {
  require(Rhipe)
  if (!exists("Rhipe.is.initialized")) {
    cat("[BlueSNP] Initializing a new Rhipe connection\n")
    rhinit(...)
    Rhipe.is.initialized <<- T
  } else {
    cat("[BlueSNP] Reusing existing Rhipe connection\n")
    Rhipe.is.initialized
  }
  hdfs.setwd(paste("/user", Sys.getenv("USER"), sep="/"))
}
